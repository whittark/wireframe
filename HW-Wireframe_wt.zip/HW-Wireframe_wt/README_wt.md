# Float exercise wt

HEADER: This you did for us. Thank you!

LEFT: reduced right border and margin to 0; float: left ; increased width to 32%.

MIDDLE: reduced right and left borders and margins to 0; display: inline-block ; width: 36%.

RIGHT: reduced left border and margin to 0; float: right ; increased width to 32%.

FULL: changed color to red so I could see it (good trick you showed us!); positon: absolute . Changed color to light gray after arranging the division and aside.

DIVISION: Modified color to blue, width, and added z-index: -1 to indicate that it's behind the other section. Used margin top value to move the element into position.

ASIDE: z-index: 1 to indicate that it's in front of division; modified the width, height, and color; padded to move it to the right.

FOOTER: margin top to 250px to bring it down; changed to inline block.





